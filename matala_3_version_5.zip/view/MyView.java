package view;

import java.util.ArrayList;

import controller.Controller;

/**
 * <h1> Class MyView </h1>
 * This class performs tasks:<br>
 * 1) Calculate(some problem) - sends it to Controller<br>
 * 2) Display solution to the user - get it from Controller
 * 
 * @author Valery Polonsky & Tomer Dricker
 */
public class MyView extends CommonView {


	CLI cli;
	
	public MyView(Controller ctr) {
		super(ctr);
		this.cli = new CLI(ctr.getHash());
	}
	
	/**
	 * This method starts the CLI
	 */
	@Override
	public void start() {
		cli.run();	
	}
	/**
	 * This method get a path and display it for user
	 */
	public void displayDir(ArrayList<String> str){
			System.out.println(str);
	}
	/**
	 * This method gets a message that the maze is ready and displays it for user
	 */
	public void displayMazeReady(String str){
		System.out.println(str);
	}
	/**
	 * This method get a list of mazes3d names and displays it for user
	 */
	@Override
	public void displayListOfNamesOfMaze(ArrayList<String> names) {
		for (String name : names){
			System.out.println(name);
		}
		
	}
	/**
	 * This method gets an error message and displays it for user
	 * @param string - Error to display
	 */
	@Override
	public void displayError(String string) {
		System.out.println(string);
	}
	/**
	 * This method gets a name of the maze,and the maze itself represented as 
	 * an array of Integers and displays it to the user.
	 */

	@Override
	public void display3dmaze(String name,int[][][] arr) {
		System.out.println("The maze: " + name);
		for (int i = 0; i < arr[0].length; i++) {
			for (int j = 0; j < arr.length; j++) {
				for (int j2 = 0; j2 < arr[i][j].length; j2++) {
						System.out.print(arr[j][i][j2]+" ");
				}
				System.out.println();
			}
			System.out.println("\n\n");
		}
		
	}
	/**
	 * This method get a cross section of the maze and displays it to the user
	 */
	@Override
	public void displayCrossSection(int[][] mat) {
		for (int i = 0; i < mat[0].length; i++) {
			for (int j = 0; j < mat.length; j++) {
				System.out.print(mat[j][i]+" ");
			}
			System.out.println();
		}
		
	}
	/**
	 * This method gets a message and displays it to the user
	 */
	@Override
	public void displayMazeSaved(String string) {
		System.out.println(string);
		
	}
	/**
	 * This method gets a message and displays it to user
	 */
	@Override
	public void displayMazeLoaded(String string) {
		System.out.println(string);
	}
	/**
	 * This method gets a message and displays it for user
	 */
	@Override
	public void displaySolveMaze(String string) {
		System.out.println(string);
	}
	/**
	 * This method gets a message and displays it to the user
	 */
	@Override
	public void displaySolution(String string) {
		System.out.println(string);
	}
	/**
	 * This method get a message and display it to the user
	 */
	@Override
	public void displayFileSize(String string) {
		System.out.println(string);
	}
	/**
	 * This method gets a message and display it to the user
	 */
	@Override
	public void displayMazeSize(String string) {
		System.out.println(string);
	}
	

	
	


}


