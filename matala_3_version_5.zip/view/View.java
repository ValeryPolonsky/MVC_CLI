package view;

import java.util.ArrayList;

/**
 * <h1> Class View </h1>
 * display all the solutions/messages from Controller
 * 
 * 
 * 
 * @author Valery Polonsky & Tomer Dricker
 *
 */
public interface View {

	void start();
	
	/**
	 * Gets a list of files in any directory and displays it for the user (getting from Controller)
	 * @param ArrayList<String> all the files in exist dir
	 */
	void displayDir(ArrayList<String> results);
	/**
	 * Gets a message that the maze is ready and displays it for the user (getting from Controller)
	 * @param results
	 */
	void displayMazeReady(String str);
	/**
	 * Gets a list of mazes that the user created and displays it to the user (getting from Controller)
	 * @param arrayList<String> maze's names
	 */
	void displayListOfNamesOfMaze(ArrayList<String> names);
	/**
	 * Gets an error message and displays it to the user (getting from Controller)
	 * @param string
	 */
	void displayError(String string);
	/**
	 * Gets a maze3d and displays it to the user (getting from Controller)
	 * @param array
	 */
	void display3dmaze(String name,int[][][] arr);
	/**
	 * Gets a two dimensional matrix by any cross Section (x,y,z) and displays it to the user (getting from Controller)
	 * @param array
	 */
	void displayCrossSection(int[][] mat);
	/**
	 * Gets a message that the maze is has been saved and displays it to the user (getting from Controller)
	 * @param string
	 */
	void displayMazeSaved(String string);
	/**
	 * Gets a message that the maze has been loaded and displays it to the user (getting from Controller)
	 * @param string
	 */
	void displayMazeLoaded(String string);
	/**
	 * Gets a message that the maze has been saved and displays it to the user (getting from Controller)
	 * @param string
	 */
	void displaySolveMaze(String string);
	/**
	 * Gets a string with all solution moves and displays it to the user (getting from Controller)
	 * @param string
	 */
	void displaySolution(String string);
	/**
	 * Gets a string with the file size and displays it to the user (getting from Controller)
	 * @param string
	 */
	void displayFileSize(String string);
	/**
	 * Gets a string with maze name and displays it (getting from Controller)
	 * @param string
	 */
	void displayMazeSize(String string);
}
