package view;

import controller.Controller;

/**
 * <h1> Class CommonView </h1>
 * This class has a data member of Controller type<br>
 * with this data member we can:<br>
 * 1)Send objects to Controller<br>
 * 2)Generate a problem and solved it with Model via Controller
 * 
 * @author Valery Polonsky & Tomer Dricker
 * 
 */
public abstract class CommonView implements View{

	Controller ctr;
	
	/**
	 * C'tor that sets the controller
	 * @param ctr - Controller to be set
	 */
	public CommonView(Controller ctr)
	{
		this.ctr = ctr;
	}
}
