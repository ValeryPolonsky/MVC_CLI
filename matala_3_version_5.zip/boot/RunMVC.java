package boot;

import controller.Controller;
import controller.MyController;
import model.Model;
import model.MyModel;
import view.MyView;
import view.View;

/**
 * <h1> Class RunMVC </h1>
 * 
 * This class has a main method that runs a MVC application design
 * @author Valery Polonsky & Tomer Dricker
 */
public class RunMVC {

	public static void main(String[] args) {
		Controller ctr = new MyController();
		Model m = new MyModel(ctr);
		View v = new MyView(ctr);
		ctr.setModel(m);
		ctr.setView(v);
		v.start();
	}

}
