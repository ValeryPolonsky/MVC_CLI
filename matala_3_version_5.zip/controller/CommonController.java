package controller;

import java.util.HashMap;

import model.Model;
import view.View;

/**
 * <h1> Class Common Controller </h1>
 * This class has three data members - to set up a connection between Model and View<br>
 * 1) Model m - this class get a problem and generates a solution<br>
 * 2) View v  - this class displays a solution and gets commands from the user<br>
 * 3) HashMap<String,Command> hash - String: saves the command name, Command: generation of the command<br>
 * 
 * 
 * @author Valery Polonsky & Tomer Dricker
 *
 */
public abstract class CommonController implements Controller {

	protected Model m;
	protected View v;
	HashMap<String,Command> hash;
	
	/**
	 * Default C'tor that allocates a new memory space for
	 * HashMap and initializes all commands in the HashMap
	 */
	public CommonController() {
		super();
		hash = new HashMap<String,Command>();
		initCommands();
	}
	/**
	 * Sets the given model to this one
	 * @param m - Model to set
	 */
	@Override
	public void setModel(Model m) {
		this.m = m;
	}
	/**
	 * Sets the given view to this view
	 * @param v - View to set
	 */
	@Override
	public void setView(View v) {
		this.v = v;
	}
	/**
	 * Returns the HashMap of commands
	 */
	@Override
	public HashMap<String, Command> getHash() {
		return hash;
	}
}
