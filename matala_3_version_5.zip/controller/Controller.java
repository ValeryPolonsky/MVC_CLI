package controller;

import java.util.ArrayList;
import java.util.HashMap;

import model.Model;
import view.View;

/**
 * <h1> Class Controller </h1>
 * The Controller Responsible for transferring commands between the View and the Model
 * 
 * 
 * @author Valery Polonsky & Tomer Dricker
 *
 */
public interface Controller {

	/**
	 * Sets a model method - model will be connected to the Controller
	 * @param m - Model to be set
	 */
	void setModel(Model m);
	/**
	 * Sets a view method - view will be connected to the Controller
	 * @param v - View to be set
	 */
	void setView(View v);
	/**
	 * Initializes all commands for user interface
	 */
	void initCommands();
	/**
	 * Get method of all available commands
	 */
	public HashMap<String, Command> getHash();
	/**
	 * This method gets an AraayList with all the names of all the files that exist in the repository and send them to View Class
	 * @param ArrayList<String> results - list of exists files
	 */
	void setSolutionForDir(ArrayList<String> results);
	/**
	 * This method gets a confirm message of success to generate a Maze3d and send it to the View Class
	 * @param str - message
	 */
	void setGenerateMaze(String str);
	/**
	 * This method gets a list of existing mazes and sends it to the View Class
	 * @param names - list of all names that create by user
	 */
	void setNamesOfMazes(ArrayList<String> names);
	/**
	 * This method gets an error message and sends it to the View Class
	 * @param string - message
	 */
	void setErrorToUser(String string);
	/**
	 * This method gets an 3D array the represents a maze, name of maze and sends it to the View Class
	 * @param name - Name of the maze
	 * @param arr - 3Dim array
	 */
	void setPrint3dMaze(String name,int[][][] arr);
	/**
	 * This method gets an 2D array that represents a cross section of the maze and send it to the View Class
	 * @param mat - Cross section
	 */
	void crossSectionReady(int[][] mat);
	/**
	 * This method gets a confirm message of success to save a Maze3d and sends it to the View Class
	 * @param string - Message
	 */
	void mazeSaved(String string);
	/**
	 * This method gets a confirm message of success to load a Maze3d and sends it to the View Class
	 * @param string - Message
	 */
	void mazeLoaded(String string);
	/**
	 * This method gets a confirm message of success to solve the Maze3d and sends it to the View Class
	 * @param string - message
	 */
	void solveMaze(String string);
	/**
	 * This method gets an algorithm's solution and sends it to the View Class
	 * @param string - Steps of the solution
	 */
	void setSolution(String string);
	/**
	 * This method gets a file size and sends it to the View Class
	 * @param string - File size
	 */
	void setFileSize(String string);
	/**
	 * This method gets a maze size and sends it to the View Class
	 * @param string - Maze size
	 */
	void setMazeSize(String string);


	

}
