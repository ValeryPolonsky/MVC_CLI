package controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * <h1> Class MyController </h1>
 * This class gets a problem from a View Class and send the problem to the Model class
 * @author Valery Polonsky & Tomer Dricker
 * 
 */
public class MyController extends CommonController {

	/**
	 * Initializes all commands for using MVC application design.
	 */
	@Override
	public void initCommands() {
		this.hash = new HashMap<String,Command>();
	
		
		this.hash.put("Dir", new Command() {
			@Override
			public void doCommand(ArrayList<String> string) {
				m.dir(new File(string.get(0)));
				
			}
		});
		
		this.hash.put("generateMaze", new Command() {
			@Override
			public void doCommand(ArrayList<String> string) {
				m.generateMaze(string);
			}
		});
		this.hash.put("displayMaze", new Command() {
			@Override
			public void doCommand(ArrayList<String> string) {
				m.displayMaze(string);
			}
		});
		this.hash.put("showListOfMaze", new Command() {
			@Override
			public void doCommand(ArrayList<String> string) {
				m.showListOfMaze(string);
			}
		});
		this.hash.put("getCrossSection", new Command() {
			@Override
			public void doCommand(ArrayList<String> string) {
				m.getCrossSection(string);
			}
		});
		this.hash.put("saveMaze", new Command() {
			@Override
			public void doCommand(ArrayList<String> string) throws IOException {
				m.saveMaze(string);
			}
		});
		this.hash.put("loadMaze", new Command() {
			@Override
			public void doCommand(ArrayList<String> string) throws IOException {
				m.loadMaze(string);
			}
		});
		this.hash.put("solveMaze", new Command() {
			@Override
			public void doCommand(ArrayList<String> string) throws IOException {
				m.solveMaze(string);
			}
		});
		this.hash.put("displaySolution", new Command() {
			@Override
			public void doCommand(ArrayList<String> string) throws IOException {
				m.displaySolution(string);
			}
		});
		this.hash.put("fileSize", new Command() {
			@Override
			public void doCommand(ArrayList<String> string) throws IOException {
				m.displayFileSize(string);
			}
		});
		this.hash.put("mazeSize", new Command() {
			@Override
			public void doCommand(ArrayList<String> string) throws IOException {
				m.displayMazeSize(string);
			}
		});
		this.hash.put("exit", new Command() {
			@Override
			public void doCommand(ArrayList<String> string) {
				m.stop();
				
			}
		});
		
}
	/**
	 * A solution method for the View part in MVC
	 */
	@Override
	public void setSolutionForDir(ArrayList<String> results) {
		v.displayDir(results);
		
	}
	/**
	 * Sets generated maze in the view part in MVC
	 */
	@Override()
	public void setGenerateMaze(String str) {
		v.displayMazeReady(str);
	}
	/**
	 * Displays names of existing mazes
	 */
	@Override
	public void setNamesOfMazes(ArrayList<String> names) {
		v.displayListOfNamesOfMaze(names);
	}
	/**
	 * Displays error messages to the user
	 */
	@Override
	public void setErrorToUser(String string) {
		v.displayError(string);
		
	}
	/**
	 * Prints the maze
	 */
	@Override
	public void setPrint3dMaze(String name,int[][][] arr){
		v.display3dmaze(name,arr);
		
	}
	/**
	 * Prints the cross section
	 */
	@Override
	public void crossSectionReady(int[][] mat) {
		v.displayCrossSection(mat);
	}
	/**
	 * Saves the maze
	 */
	@Override
	public void mazeSaved(String string) {
		v.displayMazeSaved(string);
	}
	/**
	 * Loads the maze
	 */
	@Override
	public void mazeLoaded(String string) {
		v.displayMazeLoaded(string);	
	}
	/**
	 * Solves the maze
	 */
	@Override
	public void solveMaze(String string) {
		v.displaySolveMaze(string);
	}
	/**
	 * Prints solution
	 */
	@Override
	public void setSolution(String string) {
		v.displaySolution(string);
	}
	/**
	 * Sets file size
	 */
	@Override
	public void setFileSize(String string) {
		v.displayFileSize(string);
	}
	/**
	 * Sets maze size
	 */
	@Override
	public void setMazeSize(String string) {
		v.displayMazeSize(string);
	}


}
