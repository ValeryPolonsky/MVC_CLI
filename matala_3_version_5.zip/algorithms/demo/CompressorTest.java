package algorithms.demo;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;


import algorithms.mazeGenerators.Maze3d;
import algorithms.mazeGenerators.Maze3dGenerator;
import algorithms.mazeGenerators.MyMaze3dGenerator;
import in.MyDecompressorInputStream;
import io.MyCompressorOutputStream;
public class CompressorTest {

public static void run() throws Exception {
		try{
		Maze3dGenerator mg=new MyMaze3dGenerator();
		Maze3d maze=mg.generate(20, 22, 24);
		printMaze(maze);
		System.out.println("\n \n");
		OutputStream out=new MyCompressorOutputStream(new FileOutputStream("1.maz"));
		out.write(maze.toByteArray());
		out.flush();
		out.close();
		InputStream in=new MyDecompressorInputStream(new FileInputStream("1.maz"));
		byte b[]=new byte[maze.toByteArray().length];
		in.read(b);
		in.close();
		Maze3d loaded=new Maze3d(b);
		printMaze(loaded);
		System.out.println();
		System.out.println(loaded.equals(maze));
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private static void printMaze(Maze3d maze3d) throws Exception
	{
		for(int y=0;y<maze3d.getHeight();y++)
		{
			System.out.println();
			System.out.println("Level: "+y);
			printSection(maze3d.getCrossSectionByY(y),"y");
		}
	}
	
	private static void printSection(int[][] CrossSection,String axis)
	{
		if(axis.equals("x"))
			System.out.println("CrossSection by X - axis");
		if(axis.equals("y"))
			System.out.println("CrossSection by Y - axis");
		if(axis.equals("z"))
			System.out.println("CrossSection by Z - axis");
		for(int i=0;i<CrossSection.length;i++)
		{
			for(int j=0;j<CrossSection[0].length;j++)
			{
				System.out.print(CrossSection[i][j]);
			}
			System.out.println();
		}	
	}
}
