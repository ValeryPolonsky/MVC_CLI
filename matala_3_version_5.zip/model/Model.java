package model;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * <h1> Class Model </h1>
 * The model is the main part of the calculation,
 * when the view need to do something he calls controllers and controllers 
 * call the model to do it.
 * When the model end it's activity it tells to the view through controller.
 * 
 * @author Valery Polonsky & Tomer Dricker
 *
 */
public interface Model {
	
	/**
	 * This method get a path and then shows all the files in path by the client request.
	 * @param path - Directory to show
	 */
	void dir(File path);
	/**
	 * This method gets an arrayList of strings that includes: nameOfMaze,width,length,height
	 * and generate a new 3d maze according to these parameters.
	 * @param  string - Array list of strings.
	 */
	void generateMaze(ArrayList<String> string);
	/**
	 * This method gets a name of maze and display the 3d maze to user by maze's name
	 * @param string - for the name of the maze
	 */
	void displayMaze(ArrayList<String> string);
	/**
	 * this method shows the list of mazes that create by user
	 * @param string - Array list of strings.
	 */
	void showListOfMaze(ArrayList<String> string);
	/**
	 * This method has to check if the parameter s is a positive integer
	 * @param s - Parameter to be checked
	 * @return true/false
	 */
	boolean isInteger(String s);
	/**
	 * This method shows the cross section of the maze axis.
	 * @param string - Needed for the name of the maze and for the axis (by order).
	 * @throws IOException
	 */
	void getCrossSection(ArrayList<String> string);
	/**
	 * This method saves the maze into a file to the project directory and uses compressor to zip the file.
	 * @param string - Needed for the name of the maze and for a new name of the file (by order).
	 * @throws IOException
	 */
	void saveMaze(ArrayList<String> string) throws IOException;
	/**
	 * This method loads the file of the maze and decompresses him.
	 * @param string - Needed for the name of the loaded maze and for the file name(by order)
	 * @throws IOException
	 */
	void loadMaze(ArrayList<String> string) throws IOException;
	/**
	 * This method solves the maze by using one of the algorithms DFS/BFS according to user choise.
	 * @param string - Needed for the name of the maze and for the algorithm (by order).
	 */
	void solveMaze(ArrayList<String> string);
	/**
	 * This method shows the solution of the solveMaze method.
	 * @param string - Needed for the name of the maze 
	 */
	void displaySolution(ArrayList<String> string);
	/**
	 * This method displays a file size.
	 * @param string - Needed for the file name 
	 */
	void displayFileSize(ArrayList<String> string);
	/**
	 * This method displays size of the maze.
	 * @param string - Neede for the maze name
	 */
	void displayMazeSize(ArrayList<String> string);
	/**
	 * This method makes a safe exit from the program
	 */
	void stop();
}
